package model;

public class Appointment{
	
	private int id;
	
	

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}

}
