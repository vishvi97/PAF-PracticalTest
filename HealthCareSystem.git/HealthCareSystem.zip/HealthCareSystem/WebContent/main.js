$(document).ready(function() {
	loadPatientData();
});

function getDetails(){
    $("#PatientSearch > tbody").empty();
	jQuery.ajax({

        url: "http://localhost:8080/HealthCareSystem/Services/patients/secured/" + $("#search_patientid").val(),
        type: "GET",
        contentType: "application/json",  
        dataType:'json',
        success: function(data, textStatus, errorThrown) {
        	patients_data = '<tr><td>${data.id}</td><td>${data.name}</td><td>LKR ${data.age}</td><td>${data.patientAddress}</td><td>${data.patientTelephone}</td><td>${data.bloodType}</td><td>${data.email}</td></tr>'
            $('#PatientSearch > tbody:last-child').append(patients_data);
        },
        error : function(jqXHR, textStatus, errorThrown) {
            tabledata = '<tr><td>Sorry No Result Found</td></tr>'
            $('#PatientSearch > tbody:last-child').append(patients_data);
        },
        timeout: 120000,
    });
};



function loadPatientData(){
	 $("#patientstable > tbody").empty();
    jQuery.ajax({
        url : "http://localhost:8082/HealthCareSystem/Services/patients",
        type: "GET",
        contentType: "application/json",  
        dataType:'json',
        success: function(data, textStatus, errorThrown) {
        	console.log(data);
        	let patients_data = "";
        	data.forEach(item => {
        		patients_data += `<tr><td>${item.id}</td><td>${item.name}</td><td>${item.email}</td><td>${item.patientAddress}</td><td>${item.age}</td><td>${item.bloodType}</td><td>${item.patientTelephone}</td>`
        		patients_data  += `<td><button class="btn btn-sm btn-danger" onclick="removePatient(${item.id})" >Delete</button></td></tr>`
        	});
        	 $('#patientstable > tbody:last-child').append(patients_data);
        	 
        },

        error : function(jqXHR, textStatus, errorThrown) {
        	console.log("error" , textStatus );	
        },
       timeout: 120000,
    })
}


function addPatient(){

    var name = $('#patientname').val();
    var age = $('#patinetAge').val();
    var email = $('#patientEmail').val();
    var address = $('#patinetAddress').val();
    var bloodtype = $('#patientBlood').val();
    var telephone = $('#patinetTelephone').val();   
   
    var dataset  =  { name : name , age : parseInt(age) , email : email , patientAddress : address , bloodType : bloodtype, patientTelephone : parseInt(telephone) }; 

	jQuery.ajax({
        url: "http://localhost:8080/HealthCareSystem/Services/patients" ,
        type: "POST",
        contentType: "application/json",  
        dataType:'json',
        data : JSON.stringify(dataset) ,
        success: function(data, textStatus, errorThrown) {
        	loadPatientData();
        },
        error : function(jqXHR, textStatus, errorThrown) {
        		alert(errorThrown);
        },
        timeout: 120000,
    });
};


function removePatient(itemid){

	console.log(itemid);

	jQuery.ajax({
        url: "http://localhost:8082/HealthCareSystem/Services/patients/"+ itemid ,
        
        type: "DELETE",
        contentType: "application/json",  
        dataType:'json',
        timeout: 120000,
    });
	
	loadPatientData();
};




